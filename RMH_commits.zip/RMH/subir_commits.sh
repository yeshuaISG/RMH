#!/usr/bin/env bash
# Ejecuta esto DENTRO de tu clon de RMH, con esta carpeta copiada encima.
# Usa tu propia identidad de git (git config user.name / user.email).
set -e
git pull origin main
git add 00_Gestion
git commit -m "docs: agrega acta constitutiva, control del proyecto y práctica Unidad I"
git add 01_Requisitos 02_Diseno
git commit -m "docs: agrega DER, ruta crítica, PERT y evidencia inicial del almacén"
git add 03_Desarrollo 04_Pruebas 05_Entregas_cliente 06_Cambios
git commit -m "chore: crea estructura de carpetas de evidencias 00 a 06"
git push origin main
